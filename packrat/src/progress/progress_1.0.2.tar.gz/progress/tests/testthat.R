library(testthat)
library(progress)

test_check("progress")
